﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
	public class Jugador : Persona
	{
		private float altura;
		private float peso;
		private Posicion posicion;

		public float Altura
		{
			get
			{
				return this.altura;
			}
		}

		public float Peso
		{
			get
			{
				return this.peso;
			}
		}
		
		public Posicion Posicion
		{
			get
			{
				return this.posicion;
			}
		}

		public Jugador(string nombre,string apellido,int edad,int dni,float peso,float altura,Posicion posicion)
			:base(nombre,apellido,edad,dni)
		{
			this.peso = peso;
			this.altura = altura;
			this.posicion = posicion;
		}

		public override string Mostrar()
		{
			StringBuilder retorno = new StringBuilder();
			retorno.Append(base.Mostrar());
			retorno.AppendLine("Posicion: " + this.Posicion + " Altura: " + this.Altura + " Peso: " + this.Peso);
			return retorno.ToString();
		}

		public override bool ValidarAptitud()
		{
			if(this.ValidarEstadoFisico())
			{
				if(this.Edad < 40)
				{
					return true;
				}
			}
			return false;
		}

		public bool ValidarEstadoFisico()
		{
			if((this.Peso / ((this.Altura)*2)) >= 18.5 && (this.Peso / ((this.Altura)*2)) <= 25)
			{
				return true;
			}
			return false;
		}
	}
}

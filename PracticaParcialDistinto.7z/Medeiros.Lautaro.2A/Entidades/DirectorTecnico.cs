﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
	public class DirectorTecnico : Persona
	{
		private int añosExperiencia;

		public int AñosExperiencia
		{
			get
			{
				return this.añosExperiencia;
			}
			set
			{
				this.añosExperiencia = value;
			}
		}

		public DirectorTecnico(string nombre,string apellido,int edad,int dni,int añosExperiencia)
			:base(nombre,apellido,edad,dni)
		{
			this.añosExperiencia = añosExperiencia;
		}

		public override bool ValidarAptitud()
		{
			if(this.AñosExperiencia >= 2)
			{
				if(this.Edad <65)
				{
					return true;
				}
			}
			return false;
		}

		public override string Mostrar()
		{
			return base.Mostrar() + " -Años de experiencia: " + this.AñosExperiencia;
		}
	}
}

﻿public enum Posicion
{
	Arquero,
	Defensor,
	Central,
	Delantero
}
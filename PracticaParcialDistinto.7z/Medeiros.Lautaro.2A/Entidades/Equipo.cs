﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
	public class Equipo
	{
		private const int cantidadMaximaJugadores = 6;
		private DirectorTecnico directorTecnico;
		private List<Jugador> jugadores;
		private string nombre;

		public DirectorTecnico DirectorTecnico
		{
			set
			{
				if(value.ValidarAptitud())
				{
					this.directorTecnico = value;
				}
			}
		}

		public string Nombre
		{
			get
			{
				return this.nombre;
			}
		}

		private Equipo()
		{
			this.jugadores = new List<Jugador>();
		}

		public Equipo(string nombre):this()
		{
			this.nombre = nombre;
		}

		public static explicit operator string(Equipo e)
		{
			StringBuilder retorno = new StringBuilder();
			retorno.AppendLine("Nombre del equipo: " + e.Nombre);
			if (Equals(e.directorTecnico,null))
			{
				retorno.AppendLine("Sin DT asignado");
			}
			else
			{
				retorno.AppendLine("Dt: "+e.directorTecnico.Mostrar());
			}
			retorno.AppendLine("Jugadores:");
			foreach(Jugador a in e.jugadores)
			{
				retorno.AppendLine(a.Mostrar());
			}
			return retorno.ToString();
		}

		public static bool operator ==(Equipo e ,Jugador j)
		{
			foreach(Jugador aux in e.jugadores)
			{
				if(Equals(aux,j))
				{
					return true;
				}
			}
			return false;
		}

		public static bool operator !=(Equipo e, Jugador j)
		{
			return !(e == j);
		}

		public static Equipo operator +(Equipo e,Jugador j)
		{
			if(e!=j)
			{
				if(e.jugadores.Count < cantidadMaximaJugadores)
				{
					if(j.ValidarAptitud())
					{
						e.jugadores.Add(j);
					}
				}
			}
			return e;
		}

		public static bool ValidarEquipo(Equipo e)
		{
			int contadorDel = 0;
			int contadorCen = 0;
			int contadorDef = 0;
			int contadorArq = 0;
			if (!Equals(e.directorTecnico,null))
			{
				foreach(Jugador j in e.jugadores)
				{
					if(j.Posicion == Posicion.Delantero)
					{
						contadorDel++;
					}
					if (j.Posicion == Posicion.Central)
					{
						contadorCen++;
					}
					if (j.Posicion == Posicion.Defensor)
					{
						contadorDef++;
					}
					if(j.Posicion == Posicion.Arquero)
					{
						contadorArq++;
					}
				}
				if(contadorArq==1 && contadorDel>0 && contadorCen>0 && contadorDef>0)
				{
					if(e.jugadores.Count == cantidadMaximaJugadores)
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}

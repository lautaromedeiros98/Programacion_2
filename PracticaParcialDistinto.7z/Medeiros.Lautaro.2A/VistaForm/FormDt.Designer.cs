﻿namespace VistaForm
{
	partial class FormDt
	{
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblNombre = new System.Windows.Forms.Label();
			this.lblApellido = new System.Windows.Forms.Label();
			this.lblEdad = new System.Windows.Forms.Label();
			this.lblDni = new System.Windows.Forms.Label();
			this.lblExperiencia = new System.Windows.Forms.Label();
			this.txtNombre = new System.Windows.Forms.TextBox();
			this.txtApellido = new System.Windows.Forms.TextBox();
			this.numericUpDownEdad = new System.Windows.Forms.NumericUpDown();
			this.numericUpDownDni = new System.Windows.Forms.NumericUpDown();
			this.numericUpDownExperiencia = new System.Windows.Forms.NumericUpDown();
			this.btnCrear = new System.Windows.Forms.Button();
			this.btnValidar = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownEdad)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownDni)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownExperiencia)).BeginInit();
			this.SuspendLayout();
			// 
			// lblNombre
			// 
			this.lblNombre.AutoSize = true;
			this.lblNombre.Location = new System.Drawing.Point(24, 66);
			this.lblNombre.Name = "lblNombre";
			this.lblNombre.Size = new System.Drawing.Size(44, 13);
			this.lblNombre.TabIndex = 0;
			this.lblNombre.Text = "Nombre";
			// 
			// lblApellido
			// 
			this.lblApellido.AutoSize = true;
			this.lblApellido.Location = new System.Drawing.Point(24, 104);
			this.lblApellido.Name = "lblApellido";
			this.lblApellido.Size = new System.Drawing.Size(44, 13);
			this.lblApellido.TabIndex = 1;
			this.lblApellido.Text = "Apellido";
			// 
			// lblEdad
			// 
			this.lblEdad.AutoSize = true;
			this.lblEdad.Location = new System.Drawing.Point(24, 138);
			this.lblEdad.Name = "lblEdad";
			this.lblEdad.Size = new System.Drawing.Size(32, 13);
			this.lblEdad.TabIndex = 2;
			this.lblEdad.Text = "Edad";
			// 
			// lblDni
			// 
			this.lblDni.AutoSize = true;
			this.lblDni.Location = new System.Drawing.Point(24, 172);
			this.lblDni.Name = "lblDni";
			this.lblDni.Size = new System.Drawing.Size(23, 13);
			this.lblDni.TabIndex = 3;
			this.lblDni.Text = "Dni";
			// 
			// lblExperiencia
			// 
			this.lblExperiencia.AutoSize = true;
			this.lblExperiencia.Location = new System.Drawing.Point(24, 206);
			this.lblExperiencia.Name = "lblExperiencia";
			this.lblExperiencia.Size = new System.Drawing.Size(62, 13);
			this.lblExperiencia.TabIndex = 4;
			this.lblExperiencia.Text = "Experiencia";
			// 
			// txtNombre
			// 
			this.txtNombre.Location = new System.Drawing.Point(90, 63);
			this.txtNombre.Name = "txtNombre";
			this.txtNombre.Size = new System.Drawing.Size(120, 20);
			this.txtNombre.TabIndex = 5;
			// 
			// txtApellido
			// 
			this.txtApellido.Location = new System.Drawing.Point(90, 101);
			this.txtApellido.Name = "txtApellido";
			this.txtApellido.Size = new System.Drawing.Size(120, 20);
			this.txtApellido.TabIndex = 6;
			// 
			// numericUpDownEdad
			// 
			this.numericUpDownEdad.Location = new System.Drawing.Point(90, 136);
			this.numericUpDownEdad.Name = "numericUpDownEdad";
			this.numericUpDownEdad.Size = new System.Drawing.Size(120, 20);
			this.numericUpDownEdad.TabIndex = 7;
			// 
			// numericUpDownDni
			// 
			this.numericUpDownDni.Location = new System.Drawing.Point(90, 170);
			this.numericUpDownDni.Name = "numericUpDownDni";
			this.numericUpDownDni.Size = new System.Drawing.Size(120, 20);
			this.numericUpDownDni.TabIndex = 8;
			// 
			// numericUpDownExperiencia
			// 
			this.numericUpDownExperiencia.Location = new System.Drawing.Point(90, 204);
			this.numericUpDownExperiencia.Name = "numericUpDownExperiencia";
			this.numericUpDownExperiencia.Size = new System.Drawing.Size(120, 20);
			this.numericUpDownExperiencia.TabIndex = 9;
			// 
			// btnCrear
			// 
			this.btnCrear.Location = new System.Drawing.Point(27, 256);
			this.btnCrear.Name = "btnCrear";
			this.btnCrear.Size = new System.Drawing.Size(75, 23);
			this.btnCrear.TabIndex = 10;
			this.btnCrear.Text = "Crear";
			this.btnCrear.UseVisualStyleBackColor = true;
			this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
			// 
			// btnValidar
			// 
			this.btnValidar.Location = new System.Drawing.Point(135, 256);
			this.btnValidar.Name = "btnValidar";
			this.btnValidar.Size = new System.Drawing.Size(75, 23);
			this.btnValidar.TabIndex = 11;
			this.btnValidar.Text = "Validar";
			this.btnValidar.UseVisualStyleBackColor = true;
			this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
			// 
			// FormDt
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(263, 316);
			this.Controls.Add(this.btnValidar);
			this.Controls.Add(this.btnCrear);
			this.Controls.Add(this.numericUpDownExperiencia);
			this.Controls.Add(this.numericUpDownDni);
			this.Controls.Add(this.numericUpDownEdad);
			this.Controls.Add(this.txtApellido);
			this.Controls.Add(this.txtNombre);
			this.Controls.Add(this.lblExperiencia);
			this.Controls.Add(this.lblDni);
			this.Controls.Add(this.lblEdad);
			this.Controls.Add(this.lblApellido);
			this.Controls.Add(this.lblNombre);
			this.Name = "FormDt";
			this.Text = "FormDt";
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownEdad)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownDni)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownExperiencia)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblNombre;
		private System.Windows.Forms.Label lblApellido;
		private System.Windows.Forms.Label lblEdad;
		private System.Windows.Forms.Label lblDni;
		private System.Windows.Forms.Label lblExperiencia;
		private System.Windows.Forms.TextBox txtNombre;
		private System.Windows.Forms.TextBox txtApellido;
		private System.Windows.Forms.NumericUpDown numericUpDownEdad;
		private System.Windows.Forms.NumericUpDown numericUpDownDni;
		private System.Windows.Forms.NumericUpDown numericUpDownExperiencia;
		private System.Windows.Forms.Button btnCrear;
		private System.Windows.Forms.Button btnValidar;
	}
}


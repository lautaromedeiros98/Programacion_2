﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
	public partial class FormDt : Form
	{
		private DirectorTecnico dt;

		public FormDt()
		{
			InitializeComponent();
			numericUpDownDni.Maximum = int.MaxValue;
		}

		private void btnCrear_Click(object sender, EventArgs e)
		{
			DirectorTecnico aux = new DirectorTecnico(txtNombre.Text, txtApellido.Text, (int)numericUpDownEdad.Value, (int)numericUpDownDni.Value, (int)numericUpDownExperiencia.Value);
			if(aux.Nombre == "" || aux.Apellido =="")
			{
				MessageBox.Show("Faltan datos");
			}
			else
			{
				this.dt = aux;
				MessageBox.Show("Se ha creado el DT!");
			}
		}

		private void btnValidar_Click(object sender, EventArgs e)
		{
			if(Equals(dt,null))
			{
				MessageBox.Show("Aun no se creo el DT");
			}
			else
			{
				if(dt.ValidarAptitud())
				{
					MessageBox.Show("DT apto");
				}
				else
				{
					MessageBox.Show("DT no apto");
				}
			}
		}
	}
}

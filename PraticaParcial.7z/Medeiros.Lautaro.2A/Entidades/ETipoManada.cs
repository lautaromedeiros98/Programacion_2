﻿public enum ETipoManada
{
    Unica,Mixta
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Grupo
    {
        private List<Mascota> _manada;
        private string _nombre;
        private static ETipoManada _tipo;

        public ETipoManada Tipo
        {
            set
            {
                _tipo = value;
            }
        }

        static Grupo()
        {
            _tipo = ETipoManada.Unica;
        }

        private Grupo()
        {
            this._manada = new List<Mascota>();
        }

        public Grupo(string nombre):this()
        {
            this._nombre = nombre;
        }

        public Grupo(string nombre,ETipoManada tipo):this(nombre)
        {
            _tipo = tipo;
        }

        public static bool operator ==(Grupo g, Mascota m)
        {
            foreach(Mascota m2 in g._manada)
            {
                if(m==m2)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Grupo g, Mascota m)
        {
            return !(g == m);
        }

        public static Grupo operator +(Grupo g,Mascota m)
        {
            if(g!=m)
            {
                g._manada.Add(m);
            }
            else
            {
                if (m is Perro)
                {
                    Console.WriteLine("Ya esta: " + ((Perro)m).ToString() + " En el grupo");
                }

                if (m is Gato)
                {
                    Console.WriteLine("Ya esta: " + ((Gato)m).ToString() + " En el grupo");
                }
            }        
            return g;
        }

        public static Grupo operator -(Grupo g,Mascota m)
        {
            if(g==m)
            {
                g._manada.Remove(m);
            }
            else
            {
                if (m is Perro)
                {
                    Console.WriteLine("No esta: " + ((Perro)m).ToString() + " En el grupo");
                }

                if (m is Gato)
                {
                    Console.WriteLine("No esta: " + ((Gato)m).ToString() + " En el grupo");
                }
            }
            return g;
        }

        public static implicit operator string (Grupo g)
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine("Grupo: " + g._nombre + " - tipo: " + _tipo);
            retorno.AppendLine("Integrantes: "+"<"+g._manada.Count+">:");
            foreach (Mascota a in g._manada)
            {
                if(a is Perro)
                {
                    retorno.AppendLine(((Perro)a).ToString());
                }

                if(a is Gato)
                {
                    retorno.AppendLine(((Gato)a).ToString());
                }
            }
            return retorno.ToString();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Gato : Mascota
    {
        public Gato(string nombre,string raza):base(nombre,raza)
        {

        }

        protected override string Ficha()
        {
            return base.DatosCompletos();
        }

        public override string ToString()
        {
            return this.Ficha();
        }

        public override bool Equals(object obj)
        {
            if(obj is Gato)
            {
                return (this == (Gato)obj);
            }
            return false;
        }

        public static bool operator ==(Gato g1,Gato g2)
        {
            if(g1.Nombre == g2.Nombre)
            {
                if(g1.Raza == g2.Raza)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Gato g1, Gato g2)
        {
            return !(g1 == g2);
        }

    }
}

public enum ETipoTinta
{
  Comun,
  ConBrillito,
  China
}

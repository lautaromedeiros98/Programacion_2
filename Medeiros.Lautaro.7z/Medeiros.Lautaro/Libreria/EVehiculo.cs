public enum EVehiculo
{
  Auto,Moto,Camion
}

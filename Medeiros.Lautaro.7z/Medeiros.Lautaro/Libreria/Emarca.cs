
public enum Emarca
{
  Honda, Ford, Zanella, Scania, Iveco ,Fiat
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria
{
  public class Sumador
  {
    private int _cantidadSumas;

    public Sumador(int sumas)
    {
      this._cantidadSumas = sumas;
    }

    public Sumador()
    :this(0)
    {

    }


  }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos

{
  public class Vehiculo
  {
    private string _patente;
    private Emarca _marca;
    private byte _cantidadRuedas;

    public Vehiculo(string p,Emarca m,byte c)
    {
      this._patente = p;
      this._marca = m;
      this._cantidadRuedas = c;
    }

    public string Patente
    {
      get
      {
        return this._patente;
      }
    }

    public Emarca Marca
    {
      get
      {
        return this._marca;
      }
    }

    public static bool operator ==(Vehiculo a, Vehiculo b)
    {
      if(a._patente == b._patente)
      {
        if(a._marca == b._marca)
        {
          return true;
        }
      }
      return false;
    }

    public static bool operator !=(Vehiculo a, Vehiculo b)
    {
      return !(a == b);
    }

    protected string MostrarVehiculo()
    {
      return "Patente: "+this._patente + "- " + "Marca: " +this._marca.ToString() + "- " + "Cantidad ruedas: " + this._cantidadRuedas + "- ";
    }
  }

  public class Auto : Vehiculo
  {
    protected int _cantidadAsientos;

    public Auto(string p, Emarca m, byte c,int c2) :base(p,m,c)
    {
      this._cantidadAsientos = c2;
    }

    public string MostrarAuto()
    {
      return base.MostrarVehiculo() + "Cantidad asientos: "+this._cantidadAsientos;
    }
  }

  public class Moto : Vehiculo
  {
    protected float _cilindrada;

    public Moto(string p, Emarca m, byte c, float c2) :base(p, m, c)
    {
      this._cilindrada = c2;
    }

    public string MostrarMoto()
    {
      return base.MostrarVehiculo() + "Cilindrada: " + this._cilindrada;
    }
  }

  public class Camion : Vehiculo
  {
    protected float _tara;

    public Camion(string p, Emarca m, byte c, float c2) : base(p, m, c)
    {
      this._tara = c2;
    }

    public string MostrarCamion()
    {
      return base.MostrarVehiculo() + "Tara:" +this._tara;
    }
  }

}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio04
{
    class Ejercicio04
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio04";




        }
    }
}

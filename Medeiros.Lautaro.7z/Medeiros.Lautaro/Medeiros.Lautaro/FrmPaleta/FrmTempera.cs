using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase6.Entidades;

namespace FrmPaleta
{
  public partial class FrmTempera : Form
  {
    private Tempera a;

    public Tempera Tempera
    {
      get
      {
        return this.a;
      }
    }

    public FrmTempera()
    {
      InitializeComponent();
      foreach(ConsoleColor a in Enum.GetValues(typeof(ConsoleColor)))
      {
        cmbColor.Items.Add(a);
      }
    }

    

    private void btnAceptar_Click(object sender, EventArgs e)
    {
      if(Equals(cmbColor.SelectedItem,null) || Equals(txtMarca.Text,null) || Equals(txtCantidad.Text,null))
      {
        this.DialogResult = DialogResult.Cancel;
      }
      else
      {        
        if(int.Parse(txtCantidad.Text) < sbyte.MaxValue && int.Parse(txtCantidad.Text)>sbyte.MinValue )
        {
          Tempera nuevaTempera = new Tempera((ConsoleColor)this.cmbColor.SelectedItem, txtMarca.Text, sbyte.Parse(txtCantidad.Text));
          this.a = nuevaTempera;
          this.DialogResult = DialogResult.OK;
        }
        else
        {
          this.DialogResult = DialogResult.Cancel;
          MessageBox.Show("Ingrese una cantidad entre : -128 y 127");
        }
      }
    }

    private void label3_Click(object sender, EventArgs e)
    {

    }

    private void FrmTempera_Load(object sender, EventArgs e)
    {

    }

    private void btnCancelar_Click(object sender, EventArgs e)
    {
      this.DialogResult = DialogResult.Cancel;
    }
  }
}

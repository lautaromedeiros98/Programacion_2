using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase6.Entidades;

namespace FrmPaleta
{
  public partial class FrmPaleta : Form
  {
    private Paleta p;//Hacerlo todo con listas

    public Paleta Paleta
    {
      get
      {
        return this.p;
      }
      set
      {
        this.p = value;
      }
    }

    public FrmPaleta()
    {
      InitializeComponent();
      p = 5;
    }

    private void btnMas_Click_1(object sender, EventArgs e)
    {
      FrmTempera a = new FrmTempera();
      a.ShowDialog();
      if(a.DialogResult == DialogResult.OK)
      { 
        p += a.Tempera;
      }
      ActualizarLstBox();
    }

    private void FrmPaleta_Load(object sender, EventArgs e)
    {
      
    }

    private void ActualizarLstBox()
    {
      lstLista.Items.Clear();
      foreach (Tempera i in p.Temperas)
      {
        lstLista.Items.Add(Tempera.Mostrar(i));
      }
    }
  }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase6.Entidades
{
  public class Paleta
  {
    private Tempera[] _temperas;
    private int _cantidadMaxima;

    private Paleta()
      :this(5)
    {
      
    }

    private Paleta(int cantidad)
    {
      _temperas = new Tempera[cantidad];
      _cantidadMaxima = cantidad;
    }

    public static implicit operator Paleta(int a)
    {
      Paleta p = new Paleta(a);
      return p;
    }

    private string Mostrar()
    {
      StringBuilder retorno = new StringBuilder();
      foreach(Tempera e in this._temperas)
      {
        if(!Equals(e,null))
        {
          retorno.AppendLine(Tempera.Mostrar(e));
        }
      }
      return retorno.ToString();
    }

    public static explicit operator string(Paleta p)
    {
      return p.Mostrar();
    }

    public static bool operator ==(Paleta p,Tempera t)
    {
      foreach(Tempera u in p._temperas)
      {
        if(u==t)
        {
          return true;
        }
      }
      return false;
    }

    public static bool operator !=(Paleta p, Tempera t)
    {
      return !(p == t);
    }

    public static Paleta operator +(Paleta p , Tempera t)
    {
      int i;
      if (p.Libre(p)>=0 && p.Libre(p)<=p._cantidadMaxima)
      {
        i = p.Libre(p);
        if (p != t)
        {
          p._temperas[i] = t;
        }
      }   
      return p;  
    }

    private int Libre(Paleta p)
    {
      int i;
        for (i = 0; i < p._cantidadMaxima; i++)
        {
          if(Equals(p._temperas[i],null))
          {
            break;
          }      
        }
        if(i<p._cantidadMaxima)
      {
        return i;
      }
        else
      {
        return -1;
      }
    }
  }
}

using System;

namespace Clase05.Entidades
{
    public class Tinta
    {

    }
}
